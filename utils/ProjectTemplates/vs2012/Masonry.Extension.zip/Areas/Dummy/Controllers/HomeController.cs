﻿using Masonry.Composition.Filters;
using System.Web.Mvc;

namespace $safeprojectname$.Areas.$safeprojectname$.Controllers
{
  [Authorize]
  public class HomeController : Controller
  {    
    [SidebarElement, NavbarElement]
    public ActionResult Index()
    {
      return View();
    }

    [SidebarElement("home", "index", "$safeprojectname$")]
    public ActionResult About()
    {
      return View();
    }
  }
}
