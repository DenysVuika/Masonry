﻿using Masonry.Extensibility;
using Masonry.Core.Web;
using System.Web.Mvc;

namespace $safeprojectname$.Areas.$safeprojectname$.Controllers
{
  [Authorize]
  public class HomeController : MasonryControllerBase
  {
    //
    // GET: /Dummy/Home/

    [SidebarElement, NavbarElement]
    public ActionResult Index()
    {
      return View();
    }

    [SidebarElement("home", "index", "$safeprojectname$")]
    public ActionResult About()
    {
      return View();
    }
  }
}
