﻿using System.Composition;
using Masonry.Composition.Verbs;

namespace $safeprojectname$.Areas.$safeprojectname$.ActionVerbs
{
  [Export(typeof(IHeaderActionVerb))]
  public class AboutHeaderVerb : IHeaderActionVerb
  {
    public string Name
    {
      get { return "About"; }
    }

    public string Action
    {
      get { return "About"; }
    }

    public string Controller
    {
      get { return "Home"; }
    }

    public string Area
    {
      get { return "$safeprojectname$"; }
    }

    public string GroupName
    {
      get { return "$safeprojectname$"; }
    }

    public int GroupOrder
    {
      get { return 100; }
    }

    public bool IsPublic
    {
      get { return false; }
    }
  }
}