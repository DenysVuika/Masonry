﻿using Masonry.Composition.Verbs;
using System.Composition;

namespace $safeprojectname$.Areas.$safeprojectname$.ActionVerbs
{
  [Export(typeof(ISidebarActionVerb))]
  public class DummyListVerb : ISidebarActionVerb
  {
    public string Name
    {
      get { return "$safeprojectname$"; }
    }

    public string Action
    {
      get { return "Index"; }
    }

    public string Controller
    {
      get { return "Home"; }
    }

    public string Area
    {
      get { return "$safeprojectname$"; }
    }
    
    public string Category
    {
      get { return SidebarCategories.Apps; }
    }

    public int Notifications
    {
      get { return 12; }
    }
  }
}