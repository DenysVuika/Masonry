﻿using System.Composition;
using Masonry.Composition.Verbs;

namespace $safeprojectname$.Areas.$safeprojectname$.ActionVerbs
{
  [Export(typeof(IHeaderActionVerb))]
  public class HomeHeaderVerb : IHeaderActionVerb
  {
    public string Name
    {
      get { return "Home"; }
    }

    public string Action
    {
      get { return "Index"; }
    }

    public string Controller
    {
      get { return "Home"; }
    }

    public string Area
    {
      get { return "$safeprojectname$"; }
    }

    public string GroupName
    {
      get { return "$safeprojectname$"; }
    }

    public int GroupOrder
    {
      get { return 0; }
    }

    public bool IsPublic
    {
      get { return false; }
    }
  }
}