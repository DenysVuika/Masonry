﻿using System.Web.Mvc;

namespace $safeprojectname$.Areas.$safeprojectname$
{
  public class $safeprojectname$AreaRegistration : AreaRegistration
  {
    public override string AreaName
    {
      get { return "$safeprojectname$"; }
    }

    public override void RegisterArea(AreaRegistrationContext context)
    {
      context.MapRoute(
        "$safeprojectname$",
        "$safeprojectname$/{controller}/{action}/{id}",
        new { controller = "Home", action = "Index", id = UrlParameter.Optional },
        new[] { GetType().Namespace + ".Controllers" });
    }
  }
}